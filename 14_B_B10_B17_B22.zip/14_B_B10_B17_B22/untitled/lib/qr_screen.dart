import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:typed_data';

class QRScreen extends StatefulWidget {
  @override
  _QRScreenState createState() => _QRScreenState();
}

class _QRScreenState extends State<QRScreen> {
  Uint8List? _qrImage; // To hold the QR code image data
  final String _data = 'https://api-ninjas.com';
  final String _format = 'png';
  final String _apiKey = 'yyom+PHRdXBJxuvuPhG9kg==DnKEusFyMRsqJCuR';

  @override
  void initState() {
    super.initState();
    _fetchQRCode();
  }

  Future<void> _fetchQRCode() async {
    final String apiUrl =
        'https://api.api-ninjas.com/v1/qrcode?data=$_data&format=$_format';
    try {
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'X-Api-Key': _apiKey,
          'Accept': 'image/png',
        },
      );

      if (response.statusCode == 200) {
        setState(() {
          _qrImage = response.bodyBytes;
        });
      } else {
        print("Error: ${response.statusCode} ${response.body}");
      }
    } catch (e) {
      print("Error fetching QR code: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('QR Code'),
      ),
      body: Center(
        child: _qrImage != null
            ? Image.memory(_qrImage!) // Display the QR code image
            : const CircularProgressIndicator(), // Show a loading indicator
      ),
    );
  }
}
