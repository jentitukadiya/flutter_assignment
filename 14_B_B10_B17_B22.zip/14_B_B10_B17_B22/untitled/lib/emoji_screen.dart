import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class EmojiScreen extends StatefulWidget {
  @override
  _EmojiScreenState createState() => _EmojiScreenState();
}

class _EmojiScreenState extends State<EmojiScreen> {
  String? emojiCharacter;
  String? emojiName;
  String apiKey = 'yyom+PHRdXBJxuvuPhG9kg==DnKEusFyMRsqJCuR';

  @override
  void initState() {
    super.initState();
    fetchRandomEmoji();
  }

  Future<void> fetchRandomEmoji() async {
    final String group = 'smileys_emotion';
    final String apiUrl = 'https://api.api-ninjas.com/v1/emoji?group=$group';

    try {
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {'X-Api-Key': apiKey},
      );

      if (response.statusCode == 200) {
        final List<dynamic> emojis = jsonDecode(response.body);
        if (emojis.isNotEmpty) {
          final randomEmoji = (emojis..shuffle()).first;
          setState(() {
            emojiCharacter = randomEmoji['character'];
            emojiName = randomEmoji['name'];
          });
        }
      } else {
        print("Error: ${response.statusCode} ${response.body}");
      }
    } catch (e) {
      print("Error fetching emoji: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Random Emoji'),
      ),
      body: Center(
        child: emojiCharacter != null && emojiName != null
            ? Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              emojiCharacter!,
              style: TextStyle(fontSize: 100),
            ),
            SizedBox(height: 20),
            Text(
              emojiName!,
              style: TextStyle(fontSize: 24),
            ),
          ],
        )
            : CircularProgressIndicator(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchRandomEmoji,
        child: Icon(Icons.refresh),
        tooltip: 'Refresh Emoji',
      ),
    );
  }
}
